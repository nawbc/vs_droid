##
## This script is sourced by /data/data/com.deskbtm.vs_droid/files/usr/bin/login before executing shell.
##

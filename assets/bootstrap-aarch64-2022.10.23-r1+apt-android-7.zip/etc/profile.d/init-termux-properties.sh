if [ ! -f /data/data/com.deskbtm.vs_droid/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.deskbtm.vs_droid/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.deskbtm.vs_droid/files/home/.termux
	cp /data/data/com.deskbtm.vs_droid/files/usr/share/examples/termux/termux.properties /data/data/com.deskbtm.vs_droid/files/home/.termux/
fi
